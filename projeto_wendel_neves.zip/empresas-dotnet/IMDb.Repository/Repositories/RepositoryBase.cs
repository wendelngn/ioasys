using IMDb.Repository;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace IMDb_API.Data
{
    public class RepositoryBase<T> : IRepository<T> where T : class
    {
        private readonly DataContext Context;

        public RepositoryBase(DataContext dbContext)
        {
            Context = dbContext;
        }

        public async Task<T> Add(T entity)
        {
            Context.Add<T>(entity);
            await Context.SaveChangesAsync();
            return entity;
        }

        public async Task<bool> Delete(T entity)
        {
            Context.Remove<T>(entity);
            var result = await Context.SaveChangesAsync();
            return result > 0;
        }

        public async Task<IEnumerable<T>> GetAsync(int skip, int take)
        {
            return await Context.Set<T>().Skip(skip).Take(take).ToListAsync();
        }

        public async Task<T> GetByIdAsync(int Id)
        {
            return await Context.Set<T>().FindAsync(new object[] { Id });
        }

        public IQueryable<T> QueryableFor()
        {
            return Context.Set<T>().AsQueryable();
        }

        public IQueryable<T> QueryableFor(Expression<Func<T, bool>> criteria)
        {
            return Context.Set<T>().Where(criteria);
        }

        public async Task<bool> SaveAllAsync()
        {
            return await Context.SaveChangesAsync() > 0;
        }

        public async Task<T> Update(T entity)
        {
            Context.Update<T>(entity);
            await Context.SaveChangesAsync();
            return entity;
        }
    }
}