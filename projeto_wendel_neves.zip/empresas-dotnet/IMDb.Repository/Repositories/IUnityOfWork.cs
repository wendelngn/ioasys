using IMDb.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace IMDb_API.Data
{
    public interface IUnityOfWork
    {
        DbContext Context { get; }
        T FindById<T>(params object[] keyValues) where T : class;
        IQueryable<T> QueryableFor<T>() where T : class;
        IQueryable<T> QueryableFor<T>(Expression<Func<T, bool>> criteria) where T : class;
        T Add<T>(T entity) where T : class;
        T Update<T>(T entity) where T : class;
        T Remove<T>(T entity) where T : class;
        T Update<T, U>(T entity, ICollection<U> list)
            where T : class
            where U : class;
    }
}