﻿using IMDb.Domain;
using Microsoft.EntityFrameworkCore;

namespace IMDb_API.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options) { }
        public DbSet<Movie> Movies { get; set; }
        public DbSet<Actor> Actor { get; set; }
        public DbSet<RatingMovie> RatingMovie { get; set; }
        public DbSet<User> User { get; set; }
    }
}