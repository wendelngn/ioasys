using System;
namespace IMDb_API
{
    /// <summary>
    /// JWT KEY
    /// TODO: Mover para arquivo de configura��o
    /// </summary>
    public static class Settings
    {
        public static string JwtKey = "f5f3fdd46f1f4439860fbbf44e3a2494";
    }
}