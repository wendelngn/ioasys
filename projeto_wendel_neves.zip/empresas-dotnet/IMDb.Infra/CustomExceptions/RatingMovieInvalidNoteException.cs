﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMDb.Infra.CustomExceptions
{
    public class RatingMovieInvalidNoteException : Exception
    {
        public RatingMovieInvalidNoteException() : base() { }

        public RatingMovieInvalidNoteException(string message) : base(message) { }
    }
    public class RatingMovieInvalidUserException : Exception
    {
        public RatingMovieInvalidUserException() : base() { }

        public RatingMovieInvalidUserException(string message) : base(message) { }

    }

}
