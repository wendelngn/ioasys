using IMDb.Business;
using IMDb.Domain;
using IMDb.Repository;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using IMDb.Business.Interfaces;
using IMDb_API.Controllers;
using IMDb.Infra.CustomExceptions;

namespace UnitTestIMDb_API
{
    [TestClass]
    public class MockManagementTests
    {
        [TestMethod]
        public async Task RatingMovieManagement_ValidarNotaSuperiorAoLimiteIgual_4()
        {
            try
            {
                //Arrange
                var mockRatingMovie = new Mock<IRepository<RatingMovie>>();
                var mockUser = new Mock<IRepository<User>>();
                var mockLogger = new Mock<ILogger<RatingMovieManagement>>();
                var mockManagement = new Mock<RatingMovieManagement>();

                // Act
                var sut = new RatingMovieManagement(mockLogger.Object, mockRatingMovie.Object, mockUser.Object);
                var ex = await Assert.ThrowsExceptionAsync<RatingMovieInvalidNoteException>(() => sut.Vote(1, 1, 5));

                // Assert
                Assert.IsTrue(ex is RatingMovieInvalidNoteException);
            }
            catch (Exception e)
            {
                Assert.Fail(e.Message);
            }
        }

        public async Task RatingMovieManagement_ValidarUsuarioComPermissaoParaVotar()
        {
            try
            {
                //Arrange
                var mockRatingMovie = new Mock<IRepository<RatingMovie>>();
                var mockUser = new Mock<IRepository<User>>();
                var mockLogger = new Mock<ILogger<RatingMovieManagement>>();
                var mockManagement = new Mock<RatingMovieManagement>();

                // Act
                var sut = new RatingMovieManagement(mockLogger.Object, mockRatingMovie.Object, mockUser.Object);
                var ex = await Assert.ThrowsExceptionAsync<RatingMovieInvalidUserException>(() => sut.Vote(1, 1, 5));

                // Assert
                Assert.IsTrue(ex is RatingMovieInvalidUserException);
            }
            catch (Exception e)
            {
                Assert.Fail(e.Message);
            }
        }
    }
}
