using IMDb_API.Data;
using IMDb.Domain;
using IMDb_API.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System.Linq;
using System.Collections.Generic;
using IMDb.Repository;
using IMDb.Business;
using IMDb.Business.Interfaces;

namespace IMDb_API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class IMDbController : ControllerBase
    {
        private IAuthenticationManagement authenticationManagement { get; set; }
        public IMDbController(IAuthenticationManagement _authenticationManagement)
        {
            authenticationManagement = _authenticationManagement;
        }

        [HttpPost]
        [Route("login")]
        [AllowAnonymous]
        public async Task<ActionResult<dynamic>> Authenticate(string userName, string password)
        {
            var user = await authenticationManagement.AuthenticateUser(userName, password);

            if (user?.ID > 0)
            {
                var token = AuthenticationService.GenerateToken(user);
                user.Pwd = "";
                return new
                {
                    user = user,
                    token = token
                };
            }
            else
            {
                return NotFound(new { message = "Usuário ou senha inválidos" });
            }
        }
    }
}
