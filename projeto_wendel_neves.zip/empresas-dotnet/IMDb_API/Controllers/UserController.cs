﻿using IMDb.Business.Interfaces;
using IMDb.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace IMDb_API.Controllers
{
    [ApiController]
    [Route("user")]
    public class UserController : ControllerBase
    {
        private IUserManagement userManagement { get; set; }

        public UserController(IUserManagement _userManagement)
        {
            userManagement = _userManagement;
        }

        [HttpPost]
        [Route("create")]
        [Authorize(Roles = "Administrator, User")]
        public async Task<ActionResult<User>> Create([FromBody] User model)
        {
            try
            {
                return await userManagement.Create(model);
            }
            catch (Exception e)
            {
                return NotFound(new { message = e.Message });
            }
        }

        [HttpPost]
        [Route("edit")]
        [Authorize(Roles = "Administrator, User")]
        public async Task<ActionResult<User>> Edit([FromBody] User model)
        {
            try
            {
                return await userManagement.Edit(model);
            }
            catch (Exception e)
            {
                return NotFound(new { message = e.Message });
            }
        }

        [HttpPost]
        [Route("delete")]
        [Authorize(Roles = "Administrator")]
        public async Task<ActionResult<bool>> Delete([FromBody] User model)
        {
            try
            {
                return await userManagement.Delete(model);
            }
            catch (Exception e)
            {
                return NotFound(new { message = e.Message });
            }
        }

        [HttpGet]
        [Route("getUsersByRange")]
        //[Authorize(Roles = "Administrator")]
        [AllowAnonymous]
        public async Task<ActionResult<List<User>>> GetUsersByRange(int skip, int take)
        {
            try
            {
                return await userManagement.GetUsersByRange(skip, take);
            }
            catch (Exception e)
            {
                return NotFound(new { message = e.Message });
            }
        }

        [HttpGet]        
        public async Task<ActionResult<int>> Retorna1()
        {
            var xx = await userManagement.GetUsersByRange(0, 1);
            return xx.ToArray()[0].ID;
            
        }
    }
}
