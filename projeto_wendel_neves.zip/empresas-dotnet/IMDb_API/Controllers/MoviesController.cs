﻿using IMDb_API.Data;
using IMDb.Domain;
using IMDb_API.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System.Linq;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using IMDb.Business;
using Microsoft.Extensions.Logging;
using IMDb.Business.Interfaces;
using System;

namespace IMDb_API.Controllers
{
    [ApiController]
    [Route("movies")]
    public class MoviesController : ControllerBase
    {
        private ILogger<UserManagement> logger;
        private IMovieManagement movieManagement { get; set; }
        private IRatingMovieManagement ratingMovieManagement { get; set; }
        public MoviesController(ILogger<UserManagement> _logger,
            IMovieManagement _movieManagement,
            IRatingMovieManagement _ratingMovieManagement)
        {
            logger = _logger;
            movieManagement = _movieManagement;
            ratingMovieManagement = _ratingMovieManagement;
        }

        [HttpPost]
        [Route("create")]
        [Authorize(Roles = "Administrator, User")]
        public async Task<ActionResult<Movie>> Create([FromBody] Movie model)
        {
            try
            {
                var movie = await movieManagement.Create(model);
                return movie;
            }
            catch (Exception e)
            {
                return NotFound(new { message = e.Message });
            }
        }

        [HttpPost]
        [Route("edit")]
        [Authorize(Roles = "Administrator, User")]
        public async Task<ActionResult<Movie>> Edit([FromBody] Movie model)
        {
            try
            {
                var updated = await movieManagement.Edit(model);
                return updated;
            }
            catch (Exception e)
            {
                return NotFound(new { message = e.Message });
            }
        }

        [HttpPost]
        [Route("delete")]
        [Authorize(Roles = "Administrator")]
        public async Task<ActionResult<bool>> Delete([FromBody] Movie model)
        {
            try
            {
                return await movieManagement.Delete(model);
            }
            catch (Exception e)
            {
                return NotFound(new { message = e.Message });
            }
        }

        [HttpPost]
        [Route("vote")]
        [Authorize(Roles = "User")]
        public async Task<ActionResult<bool>> Vote(int idMovie, int iduser, sbyte vote)
        {
            try
            {
                return await ratingMovieManagement.Vote(idMovie, iduser, vote);
            }
            catch (Exception e)
            {
                return NotFound(new { message = e.Message });
            }
        }

        [HttpGet]
        [Route("search")]
        [Authorize(Roles = "Administrator, User")]
        public async Task<ActionResult<List<Movie>>> Search(string movieName, string directorName, string genre, string actorName)
        {
            try
            {
                return await movieManagement.Search(movieName, directorName, genre, actorName);
            }
            catch (Exception e)
            {
                return NotFound(new { message = e.Message });
            }
        }

        [HttpGet]
        [Route("getMoviesByRange")]
        [Authorize(Roles = "Administrator, User")]
        public async Task<ActionResult<List<Movie>>> GetMoviesByRange(int skip, int take)
        {
            try
            {
                return await movieManagement.GetMoviesByRange(skip, take);
            }
            catch (Exception e)
            {
                return NotFound(new { message = e.Message });
            }
        }
    }
}
