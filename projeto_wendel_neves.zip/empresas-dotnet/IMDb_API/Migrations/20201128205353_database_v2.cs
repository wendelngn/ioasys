﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace IMDb_API.Migrations
{
    public partial class database_v2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
