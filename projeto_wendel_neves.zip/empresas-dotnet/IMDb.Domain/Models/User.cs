using System;
namespace IMDb.Domain
{
    public class User
    {
        public int ID { get; set; }
        public string UserName { get; set; }

        public string Pwd { get; set; }

        public string Role
        {
            get { return UserType.ToString(); }
        }

        public bool Enabled{ get; set; }

        public EnumUserType UserType { get; set; }
    }
}