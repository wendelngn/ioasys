using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace IMDb.Domain
{
    public class Movie
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public string DirectorName { get; set; }
        public string Synopsis { get; set; }
        public int Year { get; set; }
        public string Genre { set; get; }

        public double RatingAverage
        {
            get
            {                
                var rating = (this.RatingMovie != null && this.RatingMovie.Count > 0) ? 
                    this.RatingMovie.Average(x => x.Rating) 
                    : 0;

                return rating;
            }
        }

        public bool Enabled { get; set; }

        public IList<Actor> Actors { set; get; }

        public virtual List<RatingMovie> RatingMovie { get; set; }
    }
}
