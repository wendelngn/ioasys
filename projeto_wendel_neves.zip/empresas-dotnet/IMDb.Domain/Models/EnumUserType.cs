namespace IMDb.Domain
{
    public enum EnumUserType : int
    {
        Administrator = 1,
        User = 2
    }
}