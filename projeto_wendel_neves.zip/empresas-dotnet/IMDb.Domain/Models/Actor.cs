using System;
using System.Collections.Generic;

namespace IMDb.Domain
{
    public class Actor
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public virtual IList<Movie> Movie { get; set; }
    }
}