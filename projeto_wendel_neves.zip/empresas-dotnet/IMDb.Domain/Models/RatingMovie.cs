using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace IMDb.Domain
{
    public class RatingMovie
    {
        public int ID { get; set; }

        [ForeignKey("Movie")]
        public int IDMovie { get; set; }
        
        [ForeignKey("User")]        
        public int IDUser { get; set; }
        
        public int Rating { get; set; }
        
        public DateTime DateRating { get; set; }
        
        public Movie Movie { get; set; }
        
        public User User { get; set; }
    }
}