﻿using IMDb.Business.Interfaces;
using IMDb.Domain;
using IMDb.Repository;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace IMDb.Business
{
    public class AuthenticationManagement : IAuthenticationManagement
    {
        private ILogger<AuthenticationManagement> logger;
        private IRepository<User> userRepository;

        public AuthenticationManagement(ILogger<AuthenticationManagement> _logger,
            IRepository<User> _userRepository)
        {
            userRepository = _userRepository;
            logger = _logger;
        }

        public async Task<User> AuthenticateUser(string login, string password)
        {
            User authenticatedUser = null;
            try
            {
                var query_user = await userRepository
                    .QueryableFor(x => x.UserName == login && x.Pwd == password && x.Enabled == true)
                    .ToListAsync();

                if (query_user.Any())
                {
                    authenticatedUser = query_user.First();
                }
            }
            catch (Exception ex)
            {
                logger.Log(LogLevel.Critical,
                    ex,
                    this.GetType().ToString(),
                    "Method: AuthenticateUser",
                    new object[]
                    {
                        login, password
                    });

                throw;
            }

            return authenticatedUser;
        }
    }
}
