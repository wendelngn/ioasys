﻿using IMDb.Business.Interfaces;
using IMDb.Domain;
using IMDb.Infra.CustomExceptions;
using IMDb.Repository;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IMDb.Business
{
    public class UserManagement : IUserManagement
    {
        private IRepository<User> userRepository;
        private ILogger<UserManagement> logger;
        public UserManagement(ILogger<UserManagement> _logger,
            IRepository<User> _userRepository)
        {
            logger = _logger;
            userRepository = _userRepository;
        }

        public async Task<User> Create(User model)
        {
            User user = null;

            try
            {
                ValidadeUserName(model);

                user = await userRepository.Add(model);
            }
            catch (UserValidationException userEx)
            {
                logger.Log(LogLevel.Error,
                    userEx,
                    this.GetType().ToString(),
                    "Method: Create",
                    new object[]
                    {
                        model?.UserName
                    });
            }
            catch (Exception ex)
            {
                logger.Log(LogLevel.Critical,
                    ex,
                    this.GetType().ToString(),
                    "Method: Create",
                    new object[]
                    {
                        model?.UserName
                    });

                throw;
            }

            return user;
        }

        public async Task<User> Edit(User model)
        {
            User user = null;
            try
            {
                user = await userRepository.Update(model);
            }
            catch (Exception ex)
            {
                logger.Log(LogLevel.Critical,
                    ex,
                    this.GetType().ToString(),
                    "Method: Edit",
                    new object[]
                    {                        
                    });

                throw;
            }
            return user;
        }

        public async Task<bool> Delete(User model)
        {
            bool removed = false;

            try
            {
                model.Enabled = false;
                model = await userRepository.Update(model);
                removed = model.Enabled == false;
            }
            catch (Exception ex)
            {
                logger.Log(LogLevel.Critical,
                    ex,
                    this.GetType().ToString(),
                    "Method: Delete",
                    new object[]
                    {
                    });

                throw;
            }

            return removed;

        }

        public async Task<List<User>> GetUsersByRange(int skip, int take)
        {
            List<User> users = new List<User>();

            try
            {
                var result = await userRepository.GetAsync(skip, take);
                users = result.OrderBy(x => x.UserName).ToList();
            }
            catch (Exception ex)
            {
                logger.Log(LogLevel.Critical,
                    ex,
                    this.GetType().ToString(),
                    "Method: GetUsersByRange",
                    new object[]
                    {
                    });

                throw;
            }

            return users;
        }
        private void ValidadeUserName(User model)
        {
            if (userRepository.QueryableFor(x => x.UserName.ToLower().Equals(model.UserName.ToLower())).Any())
            {
                throw new UserValidationException("Nome de usuário já existe!");
            }
        }
    }
}
