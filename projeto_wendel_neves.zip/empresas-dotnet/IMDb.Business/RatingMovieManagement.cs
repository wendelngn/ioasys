﻿using IMDb.Domain;
using IMDb.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using IMDb.Business.Interfaces;
using IMDb.Infra.CustomExceptions;

namespace IMDb.Business
{
    public class RatingMovieManagement : IRatingMovieManagement
    {
        private IRepository<RatingMovie> ratingMovieRepository;
        private IRepository<User> userRepository;
        private ILogger<RatingMovieManagement> logger;
        public RatingMovieManagement(ILogger<RatingMovieManagement> _logger,
            IRepository<RatingMovie> _ratingMovieRepository,
            IRepository<User> _userRepository)
        {
            logger = _logger;
            ratingMovieRepository = _ratingMovieRepository;
            userRepository = _userRepository;
        }

        public async Task<bool> Vote(int idMovie, int iduser, sbyte vote)
        {
            bool voted = false;
            RatingMovie rating = new RatingMovie();
            try
            {
                ValidateVote(vote);
                ValidateUser(iduser);

                if (ratingMovieRepository
                .QueryableFor(x => x.IDUser == iduser && x.IDMovie == idMovie)
                .Any())
                {
                    rating = ratingMovieRepository
                    .QueryableFor(x => x.IDUser == iduser && x.IDMovie == idMovie).First();

                    rating.Rating = vote;
                    var rating_updated = await ratingMovieRepository.Update(rating);
                    voted = rating_updated.Rating == vote;
                }
                else
                {
                    rating.IDMovie = idMovie;
                    rating.IDUser = iduser;
                    rating.Rating = vote;
                    var rating_inserted = await ratingMovieRepository.Add(rating);
                    voted = rating_inserted.ID > 0;
                }

            }
            catch (Exception ex)
            {
                logger.Log(LogLevel.Critical,
                    ex,
                    this.GetType().ToString(),
                    "Method: Vote",
                    new object[]
                    {
                    });

                throw;
            }

            return voted;
        }

        private async void ValidateUser(int iduser)
        {
            var _user = await userRepository.GetByIdAsync(iduser);

            if (_user != null && _user.Enabled)
            {                
                if (_user.UserType != EnumUserType.User)
                {
                    throw new RatingMovieInvalidUserException("Perfil de usuário inválido para registrar voto");
                }
            }
            else
            {
                throw new RatingMovieInvalidUserException("Identificação de usuário não encontrada");
            }
        }

        private void ValidateVote(sbyte vote)
        {
            if (vote > 4)
            {
                throw new RatingMovieInvalidNoteException("Nota inválida! A nota não pode ser superior a 4");
            }

        }
    }
}
