﻿using IMDb.Business.Interfaces;
using IMDb.Domain;
using IMDb.Repository;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IMDb.Business
{
    public class MovieManagement : IMovieManagement
    {
        private IRepository<Movie> moviesRepository;
        private ILogger<MovieManagement> logger;

        public MovieManagement(ILogger<MovieManagement> _logger,
            IRepository<Movie> _moviesRepository)
        {
            moviesRepository = _moviesRepository;
            logger = _logger;
        }

        public async Task<Movie> Create(Movie movie)
        {
            Movie newMovie = null;
            try
            {
                if (Validate(movie))
                {
                    newMovie = await moviesRepository.Add(movie);
                }
            }
            catch (Exception ex)
            {
                logger.Log(LogLevel.Critical,
                    ex,
                    this.GetType().ToString(),
                    "Method: Create",
                    new object[]
                    {
                        movie?.Title
                    });

                throw;
            }

            return newMovie;
        }

        public async Task<Movie> Edit(Movie movie)
        {
            Movie updatedMovie = null;
            try
            {
                if (Validate(movie))
                {
                    updatedMovie = await moviesRepository.Update(movie);
                }
            }
            catch (Exception ex)
            {
                logger.Log(LogLevel.Critical,
                    ex,
                    this.GetType().ToString(),
                    "Method: Edit",
                    new object[]
                    {
                        movie?.Title
                    });

                throw;
            }

            return updatedMovie;
        }

        public async Task<bool> Delete(Movie movie)
        {
            bool deleted = false;

            try
            {
                movie.Enabled = false;
                var updated = await moviesRepository.Update(movie);
                deleted = updated.Enabled == false;
            }
            catch (Exception ex)
            {
                logger.Log(LogLevel.Critical,
                    ex,
                    this.GetType().ToString(),
                    "Method: Delete",
                    new object[]
                    {
                        movie?.ID
                    });

                throw;
            }

            return deleted;
        }

        public async Task<List<Movie>> Search(string movieName, string directorName, string genre, string actorName)
        {
            List<Movie> movies = new List<Movie>();

            try
            {
                if (!string.IsNullOrEmpty(movieName))
                {
                    var resultByTitle = await moviesRepository
                        .QueryableFor(x => x.Title.ToLower().Trim().Equals(movieName.ToLower().Trim()))
                        .ToListAsync();

                    movies.AddRange(resultByTitle);
                }

                if (!string.IsNullOrEmpty(directorName))
                {
                    var resultBydirectorName = await moviesRepository
                        .QueryableFor(x => x.DirectorName.ToLower().Trim().Equals(directorName.ToLower().Trim()))
                        .ToListAsync();

                    movies.AddRange(resultBydirectorName);
                }

                if (!string.IsNullOrEmpty(genre))
                {
                    var resultByGenre = await moviesRepository
                        .QueryableFor(x => x.Genre.ToLower().Trim().Equals(genre.ToLower().Trim()))
                        .ToListAsync();

                    movies.AddRange(resultByGenre);
                }

                if (!string.IsNullOrEmpty(actorName))
                {
                    var resultByActorName = await moviesRepository
                        .QueryableFor(x => x.Actors.Any(y => y.Name.ToLower().Trim().Equals(actorName.ToLower().Trim())))
                        .ToListAsync();

                    movies.AddRange(resultByActorName);
                }
            }
            catch (Exception ex)
            {
                logger.Log(LogLevel.Critical,
                    ex,
                    this.GetType().ToString(),
                    "Method: Search",
                    new object[]
                    {
                        movieName, directorName, genre, actorName
                    });

                throw;
            }

            return movies;
        }

        public async Task<List<Movie>> GetMoviesByRange(int skip, int take)
        {
            List<Movie> movies = new List<Movie>();

            try
            {
                var result = await moviesRepository
                    .QueryableFor()
                    .Include(x => x.RatingMovie)
                    .Skip(skip)
                    .Take(take)
                    .ToListAsync();

                movies = result
                    .OrderByDescending(x => x.RatingAverage)
                    .ThenBy(x => x.Title)
                    .ToList();
            }
            catch (Exception ex)
            {
                logger.Log(LogLevel.Critical,
                    ex,
                    this.GetType().ToString(),
                    "Method: GetMoviesByRange",
                    new object[]
                    {
                        skip, take
                    });

                throw;
            }

            return movies;
        }

        private bool MovieTitleValidate(string movieTitle)
        {
            if (!moviesRepository
                .QueryableFor(x => x.Title.ToLower() == movieTitle.ToLower())
                .Any())
            {
                return true;
            }
            else
            {
                throw new Exception("Título do filme já existe!");
            }
        }

        private bool Validate(Movie movie)
        {
            bool result;
            result = MovieTitleValidate(movie.Title);

            return result;
        }
    }
}
