﻿using IMDb.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMDb.Business.Interfaces
{
    public interface IMovieManagement
    {
        Task<Movie> Create(Movie movie);
        Task<Movie> Edit(Movie movie);
        Task<bool> Delete(Movie movie);
        Task<List<Movie>> Search(string movieName, string directorName, string genre, string actorName);
        Task<List<Movie>> GetMoviesByRange(int skip, int take);
    }
}
