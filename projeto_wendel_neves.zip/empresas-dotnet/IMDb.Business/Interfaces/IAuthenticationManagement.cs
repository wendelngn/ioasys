﻿using IMDb.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMDb.Business.Interfaces
{
    public interface IAuthenticationManagement
    {
        Task<User> AuthenticateUser(string login, string password);
    }
}
