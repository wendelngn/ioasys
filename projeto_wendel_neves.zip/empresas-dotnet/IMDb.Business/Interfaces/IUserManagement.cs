﻿using IMDb.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMDb.Business.Interfaces
{
    public interface IUserManagement
    {
        Task<User> Create(User model);
        Task<User> Edit(User model);
        Task<bool> Delete(User model);
        Task<List<User>> GetUsersByRange(int skip, int take);
    }
}
